# Repro-in-a-Box Bundle

## Scan Information

- **URL**: Unknown
- **Timestamp**: 2026-02-15T21:03:16.460Z
- **Pages Scanned**: 0
- **Total Issues**: 0
- **Duration**: 0.14s

## Issues Summary

### By Severity


### By Category


## Bundle Contents

- `scan-results.json` - Complete scan results with all detected issues
- `reproduce.sh` - Shell script to reproduce the scan
- `README.md` - This file

## How to Reproduce

1. Extract this bundle
2. Make the reproduction script executable:
   ```bash
   chmod +x reproduce.sh
   ```
3. Run the reproduction:
   ```bash
   ./reproduce.sh
   ```

## Detailed Issues

See `scan-results.json` for complete issue details including:
- Issue messages and descriptions
- Source URLs and line numbers
- Stack traces (where applicable)
- Severity and category classification
