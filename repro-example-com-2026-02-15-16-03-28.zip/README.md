# Repro-in-a-Box Bundle

## Scan Information

- **URL**: https://example.com/
- **Timestamp**: 2026-02-15T21:03:28.939Z
- **Pages Scanned**: 1
- **Total Issues**: 2
- **Duration**: 3.27s

## Issues Summary

### By Severity
- **warning**: 2

### By Category
- **accessibility**: 2

## Bundle Contents

- `scan-results.json` - Complete scan results with all detected issues
- `reproduce.sh` - Shell script to reproduce the scan
- `screenshots/` - Screenshots of pages with issues
- `README.md` - This file

## How to Reproduce

1. Extract this bundle
2. Make the reproduction script executable:
   ```bash
   chmod +x reproduce.sh
   ```
3. Run the reproduction:
   ```bash
   ./reproduce.sh
   ```

## Detailed Issues

See `scan-results.json` for complete issue details including:
- Issue messages and descriptions
- Source URLs and line numbers
- Stack traces (where applicable)
- Severity and category classification
